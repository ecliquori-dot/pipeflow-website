export default function PricingCard({plan}){
  return (
    <div className={'p-6 border rounded-lg shadow-sm '+(plan.title.includes('Pro')?'border-orange-400':'')}>
      <h3 className="text-xl font-bold">{plan.title}</h3>
      <div className="mt-2 font-extrabold text-2xl">{plan.setup} + <span className="text-lg font-bold">{plan.price}</span></div>
      <ul className="mt-4 list-disc pl-5 text-gray-700">
        {plan.bullets.map((b,i)=> <li key={i}>{b}</li>)}
      </ul>
      <div className="mt-4"><a className="btn-primary" href="/contact">Get Started</a></div>
    </div>
  )
}
