export default function Footer(){
  return (
    <footer className="bg-gray-50 border-t mt-12">
      <div className="container mx-auto px-6 py-6 flex justify-between items-center">
        <div>
          <strong>PipeFlow Systems</strong>
          <div className="text-sm text-gray-500">Websites that make your phone ring.</div>
        </div>
        <div className="text-sm text-gray-500">
          <a href="/terms">Terms</a> • <a href="/privacy">Privacy</a>
          <div className="mt-2">support@pipeflowsystems.com</div>
        </div>
      </div>
    </footer>
  )
}
