import Link from 'next/link'
export default function Navbar(){
  return (
    <header className="bg-white border-b">
      <div className="container mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img src="/logo.png" alt="logo" style={{width:44, height:44}} />
          <div><strong>PipeFlow Systems</strong><div className="text-sm text-gray-500">Websites for Plumbers & HVAC</div></div>
        </div>
        <nav className="flex gap-4">
          <Link href="/"><a className="text-gray-700">Home</a></Link>
          <Link href="/services"><a className="text-gray-700">Services</a></Link>
          <Link href="/pricing"><a className="text-gray-700">Pricing</a></Link>
          <Link href="/contact"><a className="text-gray-700">Contact</a></Link>
        </nav>
      </div>
    </header>
  )
}
