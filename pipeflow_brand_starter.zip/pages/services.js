import Navbar from '../components/Navbar'
import Footer from '../components/Footer'

export default function Services(){
  return (
    <>
      <Navbar />
      <main className="container mx-auto px-6 py-12">
        <h1 className="text-3xl font-bold">Services</h1>
        <ul className="mt-6 list-disc pl-5 text-gray-700">
          <li>Website Design & Optimization</li>
          <li>Local SEO & GMB Optimization</li>
          <li>Call Tracking & Analytics</li>
          <li>Paid Ads & Landing Pages</li>
        </ul>
      </main>
      <Footer />
    </>
  )
}
