import nodemailer from 'nodemailer';
import formidable from 'formidable-serverless';

export const config = {
  api: { bodyParser: false }
};

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  const form = new Promise((resolve, reject) => {
    const f = new formidable.IncomingForm();
    f.parse(req, (err, fields) => {
      if (err) reject(err);
      else resolve(fields);
    });
  });
  const fields = await form;
  const { name, business, phone, email, message } = fields || {};

  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST || 'smtp.example.com',
    port: Number(process.env.SMTP_PORT || 587),
    secure: false,
    auth: {
      user: process.env.SMTP_USER || 'username',
      pass: process.env.SMTP_PASS || 'password',
    }
  });

  const mailOptions = {
    from: process.env.FROM_EMAIL || 'no-reply@pipeflowsystems.com',
    to: process.env.TO_EMAIL || 'ecliquori@gmail.com',
    subject: `New lead from PipeFlow site: ${business || name}`,
    text: `Name: ${name}\nBusiness: ${business}\nPhone: ${phone}\nEmail: ${email}\nMessage: ${message}`,
  };

  try {
    await transporter.sendMail(mailOptions);
    return res.status(200).json({ ok: true });
  } catch (err) {
    console.error('Email error', err);
    return res.status(500).json({ error: 'Email failed' });
  }
}
