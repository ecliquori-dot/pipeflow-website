import Navbar from '../components/Navbar'
import Footer from '../components/Footer'
import PricingCard from '../components/PricingCard'

export default function Pricing(){
  const plans = [
    {title:'Essential Flow', setup:'$1,500', price:'$300/mo', bullets:['Custom 5-page site','GMB setup','Call tracking (1 number)']},
    {title:'Pro Flow System (Most Popular)', setup:'$2,500', price:'$750/mo', bullets:['Everything in Essential','Local SEO','Review generator']},
    {title:'PipeFlow Elite', setup:'$4,000', price:'$2,000/mo', bullets:['Full SEO + Ads','Heatmaps & Funnels','Dedicated manager']},
  ];
  return (
    <>
      <Navbar />
      <main className="container mx-auto px-6 py-12">
        <h1 className="text-3xl font-bold">Pricing</h1>
        <div className="grid md:grid-cols-3 gap-6 mt-6">
          {plans.map((p, i)=> <PricingCard key={i} plan={p} />)}
        </div>
      </main>
      <Footer />
    </>
  )
}
