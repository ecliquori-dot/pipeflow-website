import Navbar from '../components/Navbar'
import Footer from '../components/Footer'
export default function Privacy(){ return (
  <>
    <Navbar />
    <main className="container mx-auto px-6 py-12">
      <h1 className="text-2xl font-bold">Privacy Policy</h1>
      <p className="mt-4 text-gray-600">We collect basic contact info to respond to inquiries. We do not sell personal data.</p>
    </main>
    <Footer />
  </>
)}
