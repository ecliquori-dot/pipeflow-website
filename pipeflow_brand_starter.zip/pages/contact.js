import { useState } from 'react'
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'

export default function Contact(){
  const [status, setStatus] = useState('')
  async function handleSubmit(e){
    e.preventDefault()
    const form = new FormData(e.target)
    const res = await fetch('/api/sendEmail', { method:'POST', body: form })
    if(res.ok) setStatus('Message sent — we will contact you shortly.')
    else setStatus('Error sending message')
    e.target.reset()
  }
  return (
    <>
      <Navbar />
      <main className="container mx-auto px-6 py-12">
        <h1 className="text-3xl font-bold">Contact Us</h1>
        <p className="text-gray-600 mt-2">Book your free website audit and demo.</p>
        <form onSubmit={handleSubmit} className="mt-6 max-w-lg">
          <label className="block"><span className="text-sm">Name</span><input name="name" required className="input" /></label>
          <label className="block mt-3"><span className="text-sm">Business</span><input name="business" required className="input" /></label>
          <label className="block mt-3"><span className="text-sm">Phone</span><input name="phone" required className="input" /></label>
          <label className="block mt-3"><span className="text-sm">Email</span><input name="email" type="email" required className="input" /></label>
          <label className="block mt-3"><span className="text-sm">Message</span><textarea name="message" className="input" /></label>
          <div className="mt-4"><button className="btn-primary" type="submit">Send Request</button></div>
          {status && <p className="mt-3 text-green-600">{status}</p>}
        </form>
      </main>
      <Footer />
    </>
  )
}
