import Navbar from '../components/Navbar'
import Footer from '../components/Footer'
export default function Terms(){ return (
  <>
    <Navbar />
    <main className="container mx-auto px-6 py-12">
      <h1 className="text-2xl font-bold">Terms of Service</h1>
      <p className="mt-4 text-gray-600">Simple, client-friendly terms. By using our services you accept these terms.</p>
    </main>
    <Footer />
  </>
)}
