import Link from 'next/link'
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'

export default function Home() {
  return (
    <>
      <Navbar />
      <main className="container mx-auto px-6 py-12">
        <section className="flex flex-col md:flex-row items-center gap-8">
          <div className="flex-1">
            <h1 className="text-4xl font-extrabold">We Build Websites That Make Your Phone Ring — For Plumbers & HVAC</h1>
            <p className="mt-4 text-gray-600">Start getting more calls, leads, and booked jobs with our PipeFlow™ lead systems — built for trades who want results, fast.</p>
            <div className="mt-6 flex gap-3">
              <Link href="/pricing"><a className="btn-primary">See Pricing</a></Link>
              <Link href="/contact"><a className="btn-secondary">Get Free Audit</a></Link>
            </div>
          </div>
          <div className="flex-1">
            <img src="/logo.png" alt="PipeFlow logo" style={{width:260}} />
          </div>
        </section>

        <section className="mt-12">
          <h2 className="text-2xl font-semibold">How We Help</h2>
          <div className="grid md:grid-cols-3 gap-4 mt-6">
            <div className="card">📞<h4 className="font-bold">More Calls</h4><p className="text-sm text-gray-600">Conversion-first design and click-to-call.</p></div>
            <div className="card">⭐<h4 className="font-bold">Reputation</h4><p className="text-sm text-gray-600">Review funnels and GMB optimization.</p></div>
            <div className="card">⚙️<h4 className="font-bold">Ads & Funnels</h4><p className="text-sm text-gray-600">Landing pages built for paid traffic.</p></div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}
