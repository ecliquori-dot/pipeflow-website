
PipeFlow Systems - Branded Next.js Starter
-----------------------------------------
This starter is branded using the image you uploaded (public/logo.png) and the contact email preset.

Your contact email (used as default TO_EMAIL in API): ecliquori@gmail.com
Your selected domain: pipoeflowsystems.com

How to use:
1. Unzip and open this folder.
2. Install dependencies:
   npm install
3. Run dev server:
   npm run dev
4. Deploy on Vercel by connecting this repository.

Contact form:
- The API route /api/sendEmail uses nodemailer with SMTP placeholders.
- By default, TO_EMAIL is set to the email above via environment variable (TO_EMAIL).
- For production emailing you can either:
  a) Configure SMTP provider (SendGrid SMTP, Mailgun SMTP) and set SMTP_HOST, SMTP_USER, SMTP_PASS.
  b) Use a service like Formspree: change the contact form to post to your Formspree endpoint (no server needed).
  c) Use Resend or SendGrid API (replace nodemailer with their HTTP API).

To deploy:
- Push this repo to GitHub.
- Connect repo to Vercel and set environment variables:
  - SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS (if using SMTP)
  - FROM_EMAIL (optional)
  - TO_EMAIL (set to ecliquori@gmail.com)

To connect your domain pipoeflowsystems.com:
- Buy domain (Namecheap/Google Domains) and follow Vercel's domain setup (add CNAME/A records) or use Vercel's domain purchase.

Need help? Reply and I will:
- Push the repo to a GitHub repo for you (I can provide the commands).
- Deploy to Vercel with step-by-step screenshots.
- Or change the contact form to use Formspree and wire it to your email.
